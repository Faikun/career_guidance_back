package kz.careerguidance.applicationapi.entity;

public enum Category {
    IT,
    Medicine,
    Art
}
