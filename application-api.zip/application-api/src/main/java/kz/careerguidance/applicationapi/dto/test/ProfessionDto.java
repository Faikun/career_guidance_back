package kz.careerguidance.applicationapi.dto.test;

import lombok.Data;

@Data
public class ProfessionDto {
    private String name;
    private String description;
    private String key;
}
