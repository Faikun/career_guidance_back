package kz.careerguidance.applicationapi.exceptions;

public class SpecialityCreateException extends RuntimeException {
    public SpecialityCreateException(String errorMessage) {
        super(errorMessage);
    }

}
