package kz.careerguidance.applicationapi.exceptions;

public class UniversityCreateException extends RuntimeException {
    public UniversityCreateException(String errorMessage) {
        super(errorMessage);
    }

}
